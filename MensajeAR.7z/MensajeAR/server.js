const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mysql = require('mysql2');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Configurar la conexión a la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost', // Lo mismo acá, copiar y pegar
    user: '',
    password: '',
    database: '',
});

// Conectar a la base de datos
db.connect(err => {
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

let users = {}; // Almacenar los usuarios conectados por socket.id

// Servir archivos estáticos del frontend
app.use(express.static('public'));

// Socket.io lógica
io.on('connection', (socket) => {
    console.log('Un usuario se ha conectado', socket.id);

    // Guardar nombre de usuario en la base de datos
    socket.on('saveUsername', (username) => {
        if (!username) return;

        db.query('INSERT INTO users (username) VALUES (?)', [username], (err, result) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    console.warn(`El usuario "${username}" ya existe.`);
                } else {
                    console.error('Error al guardar el nombre de usuario:', err);
                }
                return;
            }
            console.log(`Usuario "${username}" guardado en la base de datos.`);
        });
    });

    // Evento de ingreso al chat
    socket.on('join', (username) => {
        users[socket.id] = username;
        console.log(`${username} se ha unido al chat`);

        // Enviar mensajes previos al usuario que se une
        db.query('SELECT * FROM messages ORDER BY timestamp ASC', (err, results) => {
            if (err) {
                console.error('Error al recuperar los mensajes:', err);
                return;
            }
            socket.emit('loadMessages', results);
        });
    });

    // Recibir y guardar mensaje
    socket.on('sendMessage', (message) => {
        db.query('INSERT INTO messages (username, text) VALUES (?, ?)', [message.username, message.text], (err, result) => {
            if (err) {
                console.error('Error al guardar el mensaje:', err);
                return;
            }
            io.emit('receiveMessage', message);
        });
    });

    // Usuario desconectado
    socket.on('disconnect', () => {
        console.log('Usuario desconectado', users[socket.id]);
        delete users[socket.id];
    });
});

// Iniciar el servidor
server.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
