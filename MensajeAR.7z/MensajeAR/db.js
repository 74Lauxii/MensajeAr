const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'LocalHost',
  user: 'root', // Colocar el nombre de usuario correspondiente
  password: '', // Colocar la contraseña correspondiente
  database: '' // Colocar el nombre de la base de datos correspondiente
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Error al conectar con la base de datos:', err);
  } else {
    console.log('✅ Conexión a MySQL exitosa.');
  }
});

module.exports = connection;
